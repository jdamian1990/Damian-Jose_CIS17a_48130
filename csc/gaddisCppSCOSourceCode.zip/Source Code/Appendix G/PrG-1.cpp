// This is the main project file for VC++ application project
// generated using an Application Wizard.

#include "stdafx.h"

#using <mscorlib.dll>

using namespace System;

int _tmain()
{
   // TODO: Please replace the sample code below with your own.
   Console::WriteLine(S"Hello World");
   return 0;
} 