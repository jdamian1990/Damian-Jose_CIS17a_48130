// This program shows variable initialization.
#include <iostream>
using namespace std;

int main()
{
   int month = 2, days = 28;

   cout << "Month " << month << " has " << days << " days.\n";
   return 0;
}