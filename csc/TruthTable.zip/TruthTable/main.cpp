/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on March 18, 2013, 1:32 PM
 * You finish the truth table
 */

#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    //Headings for the truth table
    cout<<" X  Y  !X  !Y  X&&Y ";
    cout<<"X||Y  X^Y  X^Y^X  X^Y^X ";
    cout<<"!(X||Y)  !X&&!Y  !(X&&Y)  !X||!Y"<<endl;
    //output row 1
    bool x=true,y=true;
    cout<<" "<<(x?'T':'F')<<" ";
    cout<<" "<<(y?'T':'F')<<"  ";
    cout<<" "<<(!x?'T':'F')<<"  ";
    cout<<" "<<(!y?'T':'F')<<" "<<endl;
    //continue for the first row
    //output the second row
    y=false;
    cout<<" "<<(x?'T':'F')<<" ";
    cout<<" "<<(y?'T':'F')<<"  ";
    cout<<" "<<(!x?'T':'F')<<"  ";
    cout<<" "<<(!y?'T':'F')<<" "<<endl;
    //output the third row
    
    //output the fourth row
    return 0;
}

