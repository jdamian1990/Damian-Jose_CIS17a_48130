/* 
 * File:   main.cpp
 * Author: Jose
 *
 * Created on March 3, 2014, 7:51 AM
 */

#include <iostream>
//System Libraries
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here:

int main(int argc, char** argv) {
 //Declare variables
    char letter ;
 //Prompt the user what character to use
    cout<<"What character would you like to"<<endl;
    cout<<"Output a Big Letter C?"<<endl;
    cin>>letter;     
    cout<<endl<<endl;
    //Output a Big C
    cout<<"  "<<letter<<letter<<letter"  "<<endl;
    cout<<""<<letter<<"  "<<letter<<endl;
    cout<<letter<<endl;
    cout<<letter<<endl;
    cout<<letter<<endl;
    cout<<" "<<letter<<"  "<<letter<<endl;
    cout<<"  "<<letter<<letter<<letter"  "<<endl;
    //Exit stage right here
    return 0;
}

